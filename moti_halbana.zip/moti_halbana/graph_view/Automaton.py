from __future__ import annotations

import random
from decimal import Decimal
from itertools import product
from typing import Union, Iterable
# from graphviz import Digraph
import copy
import tarjan
import queue
import time
from graphviz import Digraph
import os
os.environ["PATH"] += os.pathsep + 'C:/Program Files/Graphviz/bin/'

class State:
    def __init__(self, name: str, edges=None):
        if edges is None:
            edges = {}

        self.name = name
        self.edges = edges

    def __str__(self):
        return f'[State: {self.name}, edges: {[f"{a}:{n[0].name}" for a, n in self.edges.items()]}]'

    def add_edge(self, action: str, other_state: State, prob: float = None):
        if action not in self.edges.keys():
            self.edges[action] = (other_state, prob)
        else:
            raise Exception(f'{action} already defined in state {self.name}')

    def set_prob(self, action, prob):
        self.edges[action] = (self.next(action), prob)

    def next(self, action):
        if action in self.edges.keys():
            if type(self.edges.get(action)) is tuple:
                return self.edges.get(action)[0]
            else:
                self.edges.get(action)
        else:
            raise Exception(f'Invalid action {action} from state {self.name}')


# A statemachine can represent a system under learning
def checkIsInstance(states, Iterable):
    if states is not None and states is not isinstance(states, Iterable):
        states = [states]

class Automaton():
    def __init__(self, initial_state: State, accepting_states: Union[State, Iterable[State]]):
        self.initial_state = initial_state
        self.state = initial_state

        checkIsInstance(accepting_states, Iterable)

        self.accepting_states = accepting_states

        self.Time = 0

    def __str__(self):
        states = self.get_states()

        #Hacky backslash thing
        tab = '\t'
        nl = '\n'
        return f'[DFA: \n { nl.join([f"{tab}{str(state)}" for state in states]) } ' \
               f'\n\n\t[Initial state: {self.initial_state.name}]' \
               f'\n\t[Accepting states: {[s.name for s in self.accepting_states]}]' \
               f'\n]'

    def get_states(self):
        to_visit = [self.initial_state]
        visited = []

        while len(to_visit) > 0:
            cur_state = to_visit.pop()
            if cur_state not in visited:
                visited.append(cur_state)

            try:
                for action, s in cur_state.edges.items():
                    if type(s) is tuple:
                        other_state = s[0]
                    else:
                        other_state = s
                    # p = s[1]
                    if other_state not in visited and other_state not in to_visit:
                        to_visit.append(other_state)
            except:
                print()

        return visited

    # Traverses all states and collects all possible actions (i.e. the alphabet of the language)
    def get_alphabet(self):
        states = self.get_states()
        actions = set()

        for state in states:
            actions = actions.union(set(state.edges.keys()))

        print(actions)

        return actions

    # Runs the given inputs on the state machine
    def process_input(self, inputs):
        self.state = self.initial_state
        if not isinstance(inputs, Iterable):
            inputs = [inputs]

        for input in inputs:
            try:
                nextstate = self.state.next(input)
                #print(f'({self.state.name}) ={input}=> ({nextstate.name})')
                self.state = nextstate
            except Exception as e:
                #print(e)
                return False

        return self.state in self.accepting_states

    def reset(self):
        self.state = self.initial_state

    def render_graph(self, filename, w_values=None, path=None, PRINT_GRAPH = True):
        if not PRINT_GRAPH:
            return
        timestr = time.strftime("%Y%m%d-%H%M%S")
        if path is not None:
            filename_path = f"{path}/{filename}"
        else:
            filename_path = 'graphs/' + filename + '-' + timestr
        g = Digraph('G', filename=filename_path)
        g.attr(rankdir='LR')

        # Collect nodes and edges
        to_visit = [self.initial_state]
        visited = []

        # Hacky way to draw start arrow pointing to first node
        g.attr('node', shape='none')

        g.node('startz', label='', _attributes={'height': '0', 'width': '0'})

        # Draw initial state
        if self.initial_state in self.accepting_states:
            g.attr('node', shape='doublecircle')
        else:
            g.attr('node', shape='circle')

        label = str(self.initial_state.name + '\t' + str(round(float(w_values[self.initial_state.name]), 1))) if w_values is not None and w_values[self.initial_state.name] is not None else self.initial_state.name
        g.node(name=self.initial_state.name, label=label)

        g.edge('startz', self.initial_state.name)

        while len(to_visit) > 0:
            cur_state = to_visit.pop()
            visited.append(cur_state)

            g.attr('node', shape='circle')
            for action, dest in cur_state.edges.items():
                # Draw other states, but only once
                other_state = dest[0]
                prob = dest[1]
                if other_state not in visited and other_state not in to_visit:
                    to_visit.append(other_state)
                    if other_state in self.accepting_states:
                        g.attr('node', shape='doublecircle')

                        label = str(other_state.name + '\t' + str(round(float(w_values[other_state.name]),1))) if w_values is not  None and w_values[other_state.name] is not None else other_state.name
                        g.node(name=other_state.name,
                               label=label)
                        g.attr('node', shape='circle')
                    else:
                        label = str(other_state.name + '\t' +  str(round(float(w_values[other_state.name]),1))) if w_values is not  None and w_values[other_state.name] is not None else other_state.name

                        g.node(name=other_state.name,
                               label=label)
                elif other_state in to_visit and other_state in self.accepting_states:
                    label = str(other_state.name + '\t' +  str(round(float(w_values[other_state.name]), 1))) if w_values is not None and w_values[
                        other_state.name] is not None else other_state.name

                    g.node(name=other_state.name,
                           label=label)

                # Draw edges too
                if prob is not None:
                    g.edge(cur_state.name, other_state.name, label=action + ":" + '{0:.2f}'.format(Decimal(prob)), color='blue')
                else:
                    g.edge(cur_state.name, other_state.name, label=action, color='blue')

        # s = Source(str(g), filename=filename, format="png")
        if PRINT_GRAPH:
            g.view()

    # prints all not yet visited vertices reachable from s
    # prints all vertices in DFS manner from a given source.
    def DFS(self, startState: State, g: State):
        # Initially mark all verices as not visited
        visited = dict()
        parentMap = dict()
        parentMap[startState] = None
        for s in self.get_states():
            visited[s] = False

        # Create a stack for DFS
        stack = []

        # Push the current source node.
        stack.append(startState)

        while (len(stack)):
            # Pop a vertex from stack and print it
            s = stack[-1]
            stack.pop()

            # Stack may contain same vertex twice. So
            # we need to print the popped item only
            # if it is not visited.
            if (not visited[s]):
                # print(s, end=' ')
                visited[s] = True
            if s == g: # found searched node
                trace = []
                curr = g
                while (curr != None):
                    trace.append(curr)
                    curr = parentMap[curr]
                return reversed(trace)

            # Get all adjacent vertices of the popped vertex s
            # If a adjacent has not been visited, then push it
            # to the stack.
            for a in self.get_alphabet():
                next_state = s.next(a)
                if not visited[next_state]:
                    stack.append(next_state)
                    parentMap[next_state] = s  # this line was added

        return None