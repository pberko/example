# Press the green button in the gutter to run the script.
from Automaton import State, Automaton


def test_automaton():

    #automaton
    s1 = State("s1")
    s2 = State("s2")
    s3 = State("s3")

    #s1
    s1.add_edge("a", s2, 1)
    s1.add_edge("b", s3, 1)

    #s2
    s2.add_edge("a", s2, 1)
    s2.add_edge("b", s3, 1)

    #s3
    s3.add_edge("a", s1, 1)
    s3.add_edge("b", s2, 1)

    a = Automaton(s1, [s3])

    a.render_graph("automaton")

    #simple graph
    s1 = State("s1")
    s2 = State("s2")
    s3 = State("s3")

    # s1
    s1.add_edge("a", s2, 1)
    s1.add_edge("b", s3, 1)

    # s2
    s2.add_edge("a", s2, 1)
    s2.add_edge("b", s3, 1)

    # s3
    s3.add_edge("a", s1, 1)
    s3.add_edge("b", s2, 1)

    a = Automaton(s1, [])

    a.render_graph("simple-graph")

if __name__ == '__main__':
    test_automaton()
